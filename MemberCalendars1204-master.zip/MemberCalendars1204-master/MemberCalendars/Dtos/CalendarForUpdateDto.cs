﻿namespace MemberCalendars.Dtos
{
    public class CalendarForUpdateDto
    {
        public int Cpriority { get; set; }
        public bool Cfinish { get; set; }
        public string? Cmemo { get; set; }
    }
}
