﻿
namespace MemberCalendars.Dtos
{
    public class MemberForCreationDto
    {
        public string Mname { get; set; } = string.Empty;
        public int Mage { get; set; }
    }
}
