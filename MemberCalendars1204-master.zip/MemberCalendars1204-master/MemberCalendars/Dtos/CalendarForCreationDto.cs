﻿namespace MemberCalendars.Dtos
{
    public class CalendarForCreationDto
    {
        public string Cname { get; set; } = string.Empty;
        public int Cpriority { get; set; }
    }
}
