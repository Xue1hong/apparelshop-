﻿
namespace MemberCalendars.Repositories
{
    internal class _cross
    {
        internal static async Task GetCalendarDetailsByMemberId(Guid id)
        {
            throw new NotImplementedException();
        }
    }
}